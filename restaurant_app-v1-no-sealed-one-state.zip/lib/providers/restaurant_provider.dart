import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../models/restaurant.dart';
import '../models/api_response.dart';

class RestaurantProvider extends ChangeNotifier {
  ApiResponse<List<Restaurant>> _restaurants = Loading<List<Restaurant>>();
  ApiResponse<Restaurant> _restaurantDetail = Loading<Restaurant>();
  ApiResponse<List<Restaurant>> _searchResults = Loading<List<Restaurant>>();

  String _searchQuery = '';
  bool _isAddingReview = false;
  String? _reviewError;

  final String _baseUrl = 'https://restaurant-api.dicoding.dev';

  ApiResponse<List<Restaurant>> get restaurants => _restaurants;
  ApiResponse<Restaurant> get restaurantDetail => _restaurantDetail;
  ApiResponse<List<Restaurant>> get searchResults => _searchResults;
  String get searchQuery => _searchQuery;
  bool get isAddingReview => _isAddingReview;
  String? get reviewError => _reviewError;

  RestaurantProvider() {
    fetchRestaurants();
  }

  Future<void> fetchRestaurants() async {
    _restaurants = Loading<List<Restaurant>>();
    notifyListeners();

    try {
      final response = await http.get(Uri.parse('$_baseUrl/list'));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final restaurantList = RestaurantListResponse.fromJson(data);
        _restaurants = Success<List<Restaurant>>(restaurantList.restaurants);
      } else {
        _restaurants = Error<List<Restaurant>>(
            'Failed to load restaurants: ${response.statusCode}');
      }
    } catch (e) {
      _restaurants = Error<List<Restaurant>>('Failed to load restaurants: $e');
    }

    notifyListeners();
  }

  Future<void> fetchRestaurantDetail(String id) async {
    _restaurantDetail = Loading<Restaurant>();
    notifyListeners();

    try {
      final response = await http.get(Uri.parse('$_baseUrl/detail/$id'));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final restaurantDetail = RestaurantDetailResponse.fromJson(data);
        _restaurantDetail = Success<Restaurant>(restaurantDetail.restaurant);
      } else {
        _restaurantDetail =
            Error<Restaurant>('Failed to load details: ${response.statusCode}');
      }
    } catch (e) {
      _restaurantDetail = Error<Restaurant>('Failed to load details: $e');
    }

    notifyListeners();
  }

  Future<void> searchRestaurants(String query) async {
    _searchQuery = query;
    _searchResults = Loading<List<Restaurant>>();
    notifyListeners();

    try {
      final response = await http.get(Uri.parse('$_baseUrl/search?q=$query'));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final searchResult = SearchResponse.fromJson(data);
        _searchResults = Success<List<Restaurant>>(searchResult.restaurants);
      } else {
        _searchResults =
            Error<List<Restaurant>>('Failed to search: ${response.statusCode}');
      }
    } catch (e) {
      _searchResults = Error<List<Restaurant>>('Failed to search: $e');
    }

    notifyListeners();
  }

  Future<bool> addReview(String id, String name, String review) async {
    _isAddingReview = true;
    _reviewError = null;
    notifyListeners();

    print('=== SENDING REVIEW ===');
    print('ID: $id');
    print('Name: $name');
    print('Review: $review');

    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/review'),
        headers: {
          'Content-Type': 'application/json',
        },
        body: json.encode({
          'id': id,
          'name': name,
          'review': review,
        }),
      );

      print('Response Status: ${response.statusCode}');
      print('Response Body: ${response.body}');

      // PERBAIKAN DISINI: API mengembalikan 201 bukan 200
      if (response.statusCode == 201 || response.statusCode == 200) {
        final data = json.decode(response.body);

        // Debug: print response
        print('Review response decoded: $data');

        // Check if there's an error in the response
        if (data['error'] == true) {
          _reviewError = data['message'] ?? 'Failed to add review';
          _isAddingReview = false;
          notifyListeners();
          return false;
        }

        // Parse the response to get updated reviews
        try {
          final reviewResponse = ReviewResponse.fromJson(data);

          // Update restaurant detail with new reviews
          if (_restaurantDetail is Success<Restaurant>) {
            final currentRestaurant =
                (_restaurantDetail as Success<Restaurant>).data;
            final updatedRestaurant = Restaurant(
              id: currentRestaurant.id,
              name: currentRestaurant.name,
              description: currentRestaurant.description,
              pictureId: currentRestaurant.pictureId,
              city: currentRestaurant.city,
              rating: currentRestaurant.rating,
              address: currentRestaurant.address,
              menus: currentRestaurant.menus,
              customerReviews: reviewResponse.customerReviews,
            );

            _restaurantDetail = Success<Restaurant>(updatedRestaurant);
          }

          _isAddingReview = false;
          notifyListeners();
          return true;
        } catch (e) {
          print('Error parsing review response: $e');
          _reviewError = 'Error processing response: $e';
          _isAddingReview = false;
          notifyListeners();
          return false;
        }
      } else {
        _reviewError =
            'Server error: ${response.statusCode} - ${response.body}';
        _isAddingReview = false;
        notifyListeners();
        return false;
      }
    } catch (e) {
      print('Network error: $e');
      _reviewError = 'Network error: $e';
      _isAddingReview = false;
      notifyListeners();
      return false;
    }
  }

  void clearSearch() {
    _searchResults = Loading<List<Restaurant>>();
    _searchQuery = '';
    notifyListeners();
  }

  void clearReviewError() {
    _reviewError = null;
    notifyListeners();
  }
}
