import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/api_response.dart';
import '../models/restaurant.dart';
import '../providers/restaurant_provider.dart';
import '../providers/theme_provider.dart';
import '../widgets/error_widget.dart';
import '../widgets/loading_indicator.dart';
import '../widgets/restaurant_card.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = context.watch<ThemeProvider>();
    final restaurantProvider = context.watch<RestaurantProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Restaurant App'),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              Navigator.pushNamed(context, '/search');
            },
          ),
          // Ganti tema
          IconButton(
            icon: AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              transitionBuilder: (child, animation) {
                return ScaleTransition(
                  scale: animation,
                  child: child,
                );
              },
              child: themeProvider.isDarkMode
                  ? const Icon(
                      Icons.light_mode,
                      key: ValueKey('light'),
                      color: Colors.amber,
                    )
                  : const Icon(
                      Icons.dark_mode,
                      key: ValueKey('dark'),
                      color: Color.fromARGB(255, 57, 59, 60),
                    ),
            ),
            onPressed: () {
              // Toggle tema
              themeProvider.toggleTheme(!themeProvider.isDarkMode);
            },
          ),
        ],
      ),
      body: _buildBody(restaurantProvider),
    );
  }

  Widget _buildBody(RestaurantProvider provider) {
    final state = provider.restaurants;

    if (state is Loading<List<Restaurant>>) {
      return const LoadingIndicator(message: 'Loading restaurants...');
    } else if (state is Success<List<Restaurant>>) {
      return _buildRestaurantList(state.data);
    } else if (state is Error<List<Restaurant>>) {
      return ErrorDisplay(
        message: state.message,
        onRetry: () => provider.fetchRestaurants(),
      );
    }

    return Container();
  }

  Widget _buildRestaurantList(List<Restaurant> restaurants) {
    if (restaurants.isEmpty) {
      return const Center(
        child: Text('No restaurants found'),
      );
    }

    return RefreshIndicator(
      onRefresh: () async {
        final provider = RestaurantProvider();
        await provider.fetchRestaurants();
      },
      child: ListView.builder(
        itemCount: restaurants.length,
        itemBuilder: (context, index) {
          final restaurant = restaurants[index];
          return RestaurantCard(
            restaurant: restaurant,
            onTap: () {
              Navigator.pushNamed(
                context,
                '/detail',
                arguments: restaurant.id,
              );
            },
          );
        },
      ),
    );
  }
}
